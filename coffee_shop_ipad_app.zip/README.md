# Coffee Shop Till — iPad starter app

This is a static web app prototype populated from your uploaded menu export.

## What it does
- Touch-friendly menu buttons and categories
- Order basket and quantity changes
- Records cash/card sales (card must be taken separately on your existing terminal)
- Daily sales, order count, average order, cash/card totals and top items
- Export sales as CSV
- Download/restore a JSON backup
- Saves data in the current browser on this device

## Important limitations
- This is a starter prototype, not a certified POS or integrated payment terminal.
- Sales are stored locally in this browser and do not sync across devices.
- Browser data can be lost; export a backup every shift and test restoring it.
- The app needs to be tested thoroughly before real trading. It does not calculate VAT liability, ingredient costs or profit.
- It does not yet support staff logins, refunds, void audit controls, stock deduction, modifiers or cloud backups.

## How to open it locally
Open `index.html` on a computer to test. For iPad Safari use a hosted HTTPS link, described below.

## Free hosting with a permanent-style Safari link using GitHub Pages
1. Create or sign in to a GitHub account.
2. Create a new public repository, for example `coffee-shop-till`.
3. Upload `index.html` to the repository root and commit the change.
4. Open the repository's **Settings → Pages**.
5. Under **Build and deployment**, select **Deploy from a branch**, choose `main` and `/ (root)`, then Save.
6. Wait for GitHub Pages to publish. It will show the exact HTTPS URL, usually `https://YOUR-USERNAME.github.io/coffee-shop-till/`.
7. Open that URL in Safari on the iPad, tap Share → Add to Home Screen.
8. Test a dummy sale, export CSV, refresh Safari, and restore a backup before relying on it.

GitHub Pages is free for public repositories. The URL is stable while the repository and Pages site remain published, but it is not a domain registered in your shop's name.

## Recommended next steps before going live
- Confirm all products, variants and prices match the current menu.
- Add the VAT and accounting workflow that applies to your business.
- Test offline/network-loss behaviour; this hosted app should be treated as requiring the page to load initially.
- Decide a daily backup process and keep backups in a separate safe location.
- Keep your existing card terminal; for a card sale, take payment on the terminal first and then record it in the app.
